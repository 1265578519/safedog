#!/usr/bin/env python

import os,sys,time,socket,threading,copy,StringIO,cPickle,subprocess,fcntl,struct,signal,shutil

class cGlobalData:
    pass


gd=cGlobalData()
gd.isTest = False

def main():
	global gd
	if( len(sys.argv) > 1 ):
		if(sys.argv[1] == "test"):
			gd.isTest = True

	gd.iBit=0
	sOut,sErr = fPopen("getconf LONG_BIT")
	if( int(sOut) == 32):
		gd.iBit=32
	else :
		gd.iBit=64

	initGD()

	print "start uninstalling safedog, please wait seconds ..."
	for sCmd in gd.arrCmds:
		#print sCmd
		sOut,sErr=fPopen(sCmd)
		if(len(sOut) > 0):
			print sOut
		if(len(sErr) > 0):
			print sErr
		

	print "safedog removed done!"

	return




def fPopen(aCmd):
	p=subprocess.Popen(aCmd, shell=True, bufsize=4096,stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
	sOut = p.stdout.read()
	sErr = p.stderr.read()
	return (sOut,sErr)


def initGD():
	global gd

	gd.arrCmds=[]
	gd.arrCmds.append("killall sduibin >/dev/null 2>&1")
	gd.arrCmds.append("sdcmd exit >/dev/null 2>&1 &")
	gd.arrCmds.append("sleep 2")
	gd.arrCmds.append("killall sdsvrd >/dev/null 2>&1")

	gd.arrCmds.append("rm -rf /etc/rc2.d/S99sdboot")
	gd.arrCmds.append("rm -rf /etc/rc3.d/S99sdboot")
	gd.arrCmds.append("rm -rf /etc/rc4.d/S99sdboot")
	gd.arrCmds.append("rm -rf /etc/rc5.d/S99sdboot")
	gd.arrCmds.append("rm -rf /etc/rc6.d/S99sdboot")
	gd.arrCmds.append("rm -rf /etc/init.d/safedog")
	gd.arrCmds.append("rm -rf /etc/init.d/sdboot")
	gd.arrCmds.append("rm -rf /usr/bin/safedog")
	gd.arrCmds.append("rm -rf /usr/bin/sdboot")
	gd.arrCmds.append("rm -rf /usr/bin/sdstart")
	gd.arrCmds.append("rm -rf /usr/bin/sdsvrd")
	gd.arrCmds.append("rm -rf /usr/bin/sdcmd")
	gd.arrCmds.append("rm -rf /usr/bin/sdtest")
	gd.arrCmds.append("rm -rf /usr/bin/sdui")
	gd.arrCmds.append("rm -rf /usr/bin/sduibin")
	gd.arrCmds.append("rm -rf /usr/bin/sdcloud")
	gd.arrCmds.append("rm -rf /usr/bin/udinstall")
	if (gd.isTest ==  True):
		if(gd.iBit == 32):
			gd.arrCmds.append("uduninstall NF-7400L test")
		else:
			gd.arrCmds.append("uduninstall NF-7400L64 test")
	else:
		if(gd.iBit == 32):
			gd.arrCmds.append("uduninstall NF-7400L")
		else:
			gd.arrCmds.append("uduninstall NF-7400L64")

	gd.arrCmds.append("rm -rf /var/log/sdsvrd.log")
	gd.arrCmds.append("rm -rf /var/log/sdcmd.log")
	gd.arrCmds.append("rm -rf /var/log/sdui.log")
	gd.arrCmds.append("rm -rf /var/log/newsdui.log")
	gd.arrCmds.append("rm -rf /var/log/sdupdate.log")
	gd.arrCmds.append("rm -rf /var/log/ips.log")
	#gd.arrCmds.append("rm -rf /etc/sdsvrd.conf")
	gd.arrCmds.append("rm -rf /usr/bin/uduninstall")
	if (os.system("which sdacm 1>/dev/null 2>&1") != 0):
		gd.arrCmds.append("rm -rf /etc/safedog")
		gd.arrCmds.append("rm -rf /usr/lib/safedog")
		gd.arrCmds.append("rm -rf /usr/lib/sdcommon")
		gd.arrCmds.append("rm -rf /usr/lib/sdcc")
		gd.arrCmds.append("rm -rf /etc/init.d/sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc2.d/S99sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc3.d/S99sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc4.d/S99sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc5.d/S99sdccboot")
		gd.arrCmds.append("killall sdcc>/dev/null 2>&1")
		gd.arrCmds.append("rm -rf /usr/bin/sdcc")
		gd.arrCmds.append("rm -rf /usr/bin/runsdcc")
		gd.arrCmds.append("rm -rf /var/log/sdcc.log")
	else:
		gd.arrCmds.append("rm -rf /etc/safedog/sdsvrd.conf")
		gd.arrCmds.append("rm -rf /etc/safedog/backup")
		gd.arrCmds.append("rm -rf /etc/safedog/dmp")
		gd.arrCmds.append("rm -rf /etc/safedog/examine")
		gd.arrCmds.append("rm -rf /etc/safedog/monitor")
		gd.arrCmds.append("rm -rf /etc/safedog/update")
		gd.arrCmds.append("rm -rf /etc/safedog/*.dat")
		gd.arrCmds.append("rm -rf /etc/safedog/*.conf")
		gd.arrCmds.append("rm -rf /etc/safedog/*.html")
		
		


	if (gd.isTest !=  True):
		gd.arrCmds.append("date >> /etc/sduninstall.log")


	return






if __name__ == "__main__":
    main()
    os._exit(0)

