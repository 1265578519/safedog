#!/usr/bin/env python

import os,sys,time,socket,threading,copy,StringIO,cPickle,subprocess,fcntl,struct,signal,shutil,commands

class cGlobalData:
	pass


gd=cGlobalData()

def main():
	global gd

	gd.isTest=False
	gd.longbit=32
	
	gd.iStepAll=10
	gd.iStepNow=0
	gd.iCoverSdcc=is_cover_sdcc()


	sOut,sErr = fPopen("getenforce")
	if(sOut[0:9] == "Enforcing"):
		print "Selinux is running, can not install safedog!"
		doExit()

	mybit = 0

	sOut,sErr = fPopen("file -L dependpkg/bin/sdsvrd | awk '{print $3}'")
	if(int(sOut[0:2]) == 32):
		mybit = 32
		print "installing 32 bit safedog!"
	else:
		mybit = 64
		print "installing 64 bit safedog!"


	sOut,sErr = fPopen("getconf LONG_BIT")
	if( int(sOut) == 32):
		print "getconf LONG_BIT = ",int(sOut)
		gd.longbit=32
	else:
		print "getconf LONG_BIT = ",int(sOut)
		gd.longbit=64


	if( mybit == 32 and gd.longbit == 64 ):
		print "You need 64 bit safedog version!\nExit installation!\n"
		doExit()

	if( mybit == 64 and gd.longbit == 32 ):
		print "You need 32 bit safedog version!\nExit installation!\n"
		doExit()

	
	fPopen("sdcmd exit >/dev/null 2>&1 &")
	fPopen("sleep 3")
	fPopen("killall sdcmd >/dev/null 2>&1")
	fPopen("killall sdsvrd >/dev/null 2>&1")
	if(gd.iCoverSdcc):
		fPopen("killall sdcc >/dev/null 2>&1")
	fPopen("killall udcenter >/dev/null 2>&1")

	fPopen("mkdir -p /etc/baklibsd;rm -rf /etc/baklibsd/*")
	fPopen("mv /usr/lib/udcenter /etc/baklibsd/ 2>/dev/null")
	fPopen("mv /usr/lib/safedog /etc/baklibsd/ 2>/dev/null")
	if(gd.iCoverSdcc):
		fPopen("mv /usr/lib/sdcc /etc/baklibsd/ 2>/dev/null")
	fPopen("mv /usr/lib/sdcommon /etc/baklibsd/ 2>/dev/null")

	gd.filelibcryptopath,gd.filelibsslpath = findOpenSsl(gd.longbit)
	if( len(gd.filelibcryptopath) < 9 or len(gd.filelibsslpath) < 9 ):
		print "need openssl library for installing safedog for linux."
		print "installing exiting"
		return False
	print gd.filelibcryptopath
	print gd.filelibsslpath

	if( len(sys.argv) > 1 ):
		if(sys.argv[1] == "test"):
			gd.isTest = True

	if(not initGD()):
		doExit()

	print "step "+stepnow()+"/"+str(gd.iStepAll),", checking os release version..."

	#auto find os release version		
	sOut,sErr = fPopen("cat /etc/issue")
	sIssueRes = sOut.lower()
	iSelect = 0
	idxArrOs=1
	while( idxArrOs <=4 ):
		if( sIssueRes.find(gd.arrOsDes[idxArrOs]) != -1):
			iSelect = idxArrOs
			break
		else:
			idxArrOs += 1

	#manually set os release version
	if( iSelect > 4 or iSelect<1 ):
		print ("%s")%(gd.sInstallTip)
		inSelect=raw_input()
		while( not inSelect.isdigit() or  int(inSelect) > 5 or int(inSelect) < 1):
			print ("%s")%(gd.sInstallTip)
			inSelect=raw_input()
		iSelect = int(inSelect)
		if( iSelect > 4 or iSelect<1 ):
			doExit()
	print "your os %s"%gd.arrOs[iSelect]

	print "step "+stepnow()+"/"+str(gd.iStepAll),", check app needed..."

	#print gd.arrApplist
	for sApp in gd.arrApplist:
		sOut,sErr = fPopen("which %s"%sApp)
		#print "sOut=<"+sOut+">"
		#print "sErr=<"+sErr+">"
		if( len(sOut) == 0 ):
			print "need "+sApp+" to install safedog for linux."
			print "installing exiting!"
			doExit()

	print "step "+stepnow()+"/"+str(gd.iStepAll),", making dir..."

	if(gd.iCoverSdcc):
		arrDirs2Make=["/etc/safedog/dmp","/etc/safedog/examine","/etc/safedog/backup","/etc/safedog/monitor","/etc/safedog/update","/usr/lib/safedog","/usr/lib/sdcommon","/usr/lib/sdcc"]
	else:
		arrDirs2Make=["/etc/safedog/dmp","/etc/safedog/examine","/etc/safedog/backup","/etc/safedog/monitor","/etc/safedog/update","/usr/lib/safedog","/usr/lib/sdcommon"]
	for sDir in arrDirs2Make:
		try:
			os.makedirs(sDir,0700)
		except:
			#print "make directory:%s some error"%sDir
			pass

		if( not os.path.isdir(sDir)  ):
			print "create directory:'%s' failed!"%sDir
			print "installing exiting!"
			doExit()

	print "step "+stepnow()+"/"+str(gd.iStepAll),", installing file..."

	for sCmd in gd.arrCmds:
		sOut,sErr=fPopen(sCmd)
		if( len(sErr) >0 ):
			print "command:'%s' failed!"%sCmd
			print sErr
			doExit()

	print "step "+stepnow()+"/"+str(gd.iStepAll),", start safedog service..."
	fPopen("/usr/bin/sdstart")
	fPopen("killall udcenter >/dev/null 2>&1")
	if(gd.iCoverSdcc):
		fPopen("/usr/bin/runsdcc")
	print "step "+stepnow()+"/"+str(gd.iStepAll),", start safedog update service..."
	fPopen("/usr/bin/udcenter")
	print "step "+stepnow()+"/"+str(gd.iStepAll),", save safedog install info..."
	if (gd.isTest ==  True):
		fPopen("udinstall test")
	else:
		fPopen("udinstall")

	print "step "+stepnow()+"/"+str(gd.iStepAll),", setting os release version..."
	print fPopen("sdcmd os %s"%gd.arrOs[iSelect])[0]
	print "step "+stepnow()+"/"+str(gd.iStepAll),", setting safedog version..."
	print fPopen("sdcmd ver %s"%gd.sVersion)[0]

	fPopen("sdcmd ddostcpsyncalctime 10")
	fPopen("sdcmd ddosproxymaxcalctime 60")
	fPopen("sdcmd ddosurlfollowcalctime 300")
	fPopen("sdcmd ddosdenytimelen 9000")

	print "step "+stepnow()+"/"+str(gd.iStepAll),", ok!"

	print "Congratulations! Safedog For Linux has been installed completely!"
	print "you can run the command below to setup safedog:"
	print "sdui\n"


	return



def doExit():
	sys.exit(1)
	return





def fPopen(aCmd):
	p=subprocess.Popen(aCmd, shell=True, bufsize=4096,stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
	sOut = p.stdout.read()
	sErr = p.stderr.read()
	return (sOut,sErr)




def initGD():
	global gd

	gd.sVersion="2.4.08814"
	gd.arrOs=['','ubuntu','centos','fedora','rhel','else']
	gd.arrOsDes=['','ubuntu','centos','fedora','hat','else']
	gd.sInstallTip="please select the correct release version name of your os:\n"
	gd.sInstallTip+="[1] ubuntu\n"
	gd.sInstallTip+="[2] centos\n"
	gd.sInstallTip+="[3] fedora\n"
	gd.sInstallTip+="[4] rhel (Red Hat Enterprise Linux)\n"
	gd.sInstallTip+="[5] else or I don't know\n"

	gd.arrApplist="python cat grep egrep awk netstat df free iptables zcat ifconfig sort uniq head hostname cp echo touch ps bash tail vmstat du mv tar mkdir rm chown chmod service killall kill ifdown ifup sed basename date uname ls cut diff iptables-save iptables-restore".split()

	gd.arrCmds=[]
	gd.arrCmds.append("chmod -R 700 ./*")
	gd.arrCmds.append("chmod +x ./dependpkg/lib/*")
	gd.arrCmds.append("chmod +x ./dependpkg/bin/* ")
	gd.arrCmds.append("chmod +x ./dependpkg/script/* ")
	#gd.arrCmds.append("rm -rf /usr/lib/udcenter >/dev/null 2>&1")
	gd.arrCmds.append("rm -rf /etc/safedoginfo.conf >/dev/null 2>&1")

	gd.arrCmds.append("cp -a -f -r ./dependpkg/bin/sdsvrd /etc/safedog/dmp/")
	gd.arrCmds.append("cp -a -f -r ./dependpkg/lib/libsafedog/* /usr/lib/safedog/")
	gd.arrCmds.append("cp -a -f -r -P ./dependpkg/lib/libcommon/* /usr/lib/sdcommon/")
	if(gd.iCoverSdcc):
		gd.arrCmds.append("cp -a -f -r -P ./dependpkg/lib/libsdcc/* /usr/lib/sdcc/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/* /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/script/* /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/trust.crt /etc/safedog/")
		gd.arrCmds.append("cp -a -f ./dependpkg/safedog.csf /etc/safedog/")
		gd.arrCmds.append("cp -a -f ./dependpkg/safedog_normal.psf /etc/safedog/")
	else:
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/uduninstall /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/sdsvrd /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/udcenter /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/sd_autoexmn /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/udinstall /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/sduibin /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/sdcmd /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/udpro /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/sdalarm /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/bin/sdcloud /usr/bin/")

		gd.arrCmds.append("cp -a -f ./dependpkg/script/sdstart /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/script/udboot /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/script/safedog /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/script/sdui /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/script/sdboot /usr/bin/")
		gd.arrCmds.append("cp -a -f ./dependpkg/script/sdsetos /usr/bin/")
				 
	gd.arrCmds.append("cp -a -f ./dependpkg/examine/* /etc/safedog/examine/")
	gd.arrCmds.append("cp -a -f ./dependpkg/*.html /etc/safedog/")
	gd.arrCmds.append("cp -a -f ./dependpkg/*.conf /etc/safedog/")
#	gd.arrCmds.append("cat ./dependpkg/spider.dat >> /etc/safedog/spider.dat")
#	gd.arrCmds.append("sort /etc/safedog/spider.dat >> /etc/safedog/spider.dat.tmp")
#	gd.arrCmds.append("uniq /etc/safedog/spider.dat.tmp > /etc/safedog/spider.dat")
#	gd.arrCmds.append("rm -rf /etc/safedog/spider.dat.tmp")
	gd.arrCmds.append("cp -a -f ./dependpkg/spider.dat /etc/safedog/")


	gd.arrCmds.append("cp -a -f ./dependpkg/script/safedog /etc/init.d/")
	gd.arrCmds.append("cp -a -f ./dependpkg/script/sdboot  /etc/init.d/")

	gd.arrCmds.append("rm -f /etc/rc2.d/S99sdboot")
	gd.arrCmds.append("rm -f /etc/rc3.d/S99sdboot")
	gd.arrCmds.append("rm -f /etc/rc4.d/S99sdboot")
	gd.arrCmds.append("rm -f /etc/rc5.d/S99sdboot")
	gd.arrCmds.append("ln -s /etc/init.d/sdboot /etc/rc2.d/S99sdboot")
	gd.arrCmds.append("ln -s /etc/init.d/sdboot /etc/rc3.d/S99sdboot")
	gd.arrCmds.append("ln -s /etc/init.d/sdboot /etc/rc4.d/S99sdboot")
	gd.arrCmds.append("ln -s /etc/init.d/sdboot /etc/rc5.d/S99sdboot")

	gd.arrCmds.append("cp -a -f ./dependpkg/script/udboot  /etc/init.d/")
	gd.arrCmds.append("rm -rf /etc/rc2.d/S99udboot")
	gd.arrCmds.append("rm -rf /etc/rc3.d/S99udboot")
	gd.arrCmds.append("rm -rf /etc/rc4.d/S99udboot")
	gd.arrCmds.append("rm -rf /etc/rc5.d/S99udboot")
	gd.arrCmds.append("ln -s /etc/init.d/udboot /etc/rc2.d/S99udboot")
	gd.arrCmds.append("ln -s /etc/init.d/udboot /etc/rc3.d/S99udboot")
	gd.arrCmds.append("ln -s /etc/init.d/udboot /etc/rc4.d/S99udboot")
	gd.arrCmds.append("ln -s /etc/init.d/udboot /etc/rc5.d/S99udboot")

	if(gd.iCoverSdcc):
		gd.arrCmds.append("cp -a -f ./dependpkg/script/sdccboot  /etc/init.d/")
		gd.arrCmds.append("rm -rf /etc/rc2.d/S99sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc3.d/S99sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc4.d/S99sdccboot")
		gd.arrCmds.append("rm -rf /etc/rc5.d/S99sdccboot")
		gd.arrCmds.append("ln -s /etc/init.d/sdccboot /etc/rc2.d/S99sdccboot")
		gd.arrCmds.append("ln -s /etc/init.d/sdccboot /etc/rc3.d/S99sdccboot")
		gd.arrCmds.append("ln -s /etc/init.d/sdccboot /etc/rc4.d/S99sdccboot")
		gd.arrCmds.append("ln -s /etc/init.d/sdccboot /etc/rc5.d/S99sdccboot")

	gd.arrCmds.append("rm -f /usr/lib/safedog/libcrypto.so*")
	gd.arrCmds.append("rm -f /usr/lib/safedog/libssl.so*")
	gd.arrCmds.append("cp %s /usr/lib/safedog/libcrypto.so"%(gd.filelibcryptopath))
	gd.arrCmds.append("cp %s /usr/lib/safedog/libssl.so"%(gd.filelibsslpath))
	gd.arrCmds.append("ln -s /usr/lib/safedog/libcrypto.so /usr/lib/safedog/libcrypto.so.6")
	gd.arrCmds.append("ln -s /usr/lib/safedog/libcrypto.so /usr/lib/safedog/libcrypto.so.0.9.8")
	gd.arrCmds.append("ln -s /usr/lib/safedog/libcrypto.so /usr/lib/safedog/libcrypto.so.1.0.0")
	gd.arrCmds.append("ln -s /usr/lib/safedog/libssl.so /usr/lib/safedog/libssl.so.6")
	gd.arrCmds.append("ln -s /usr/lib/safedog/libssl.so /usr/lib/safedog/libssl.so.0.9.8")
	gd.arrCmds.append("ln -s /usr/lib/safedog/libssl.so /usr/lib/safedog/libssl.so.1.0.0")
	gd.arrCmds.append("rm -f /usr/lib/safedog/libcurl.so.3")
	gd.arrCmds.append("ln -s /usr/lib/sdcc/libcurl.so.3 /usr/lib/safedog/libcurl.so.3")
	gd.arrCmds.append("rm -f /usr/lib/safedog/libcurl.so")
	gd.arrCmds.append("ln -s /usr/lib/sdcc/libcurl.so.3 /usr/lib/safedog/libcurl.so")

	gd.arrCmds.append("rm -rf /usr/lib/sdcommon/libboost_*.so")
	gd.arrCmds.append("ln -s /usr/lib/sdcommon/libboost_system.so.1.49.0 /usr/lib/sdcommon/libboost_system.so")
	gd.arrCmds.append("ln -s /usr/lib/sdcommon/libboost_thread.so.1.49.0 /usr/lib/sdcommon/libboost_thread.so")
	gd.arrCmds.append("ln -s /usr/lib/sdcommon/libboost_filesystem.so.1.49.0 /usr/lib/sdcommon/libboost_filesystem.so")
	gd.arrCmds.append("ln -s /usr/lib/sdcommon/libboost_regex.so.1.49.0 /usr/lib/sdcommon/libboost_regex.so")

	gd.arrCmds.append("chmod -R 700 /usr/lib/safedog")
	gd.arrCmds.append("chmod -R 700 /usr/lib/sdcommon")
	gd.arrCmds.append("chmod -R 700 /usr/lib/sdcc")
	gd.arrCmds.append("chmod -R 700 /etc/safedog")
	if(os.path.exists("/etc/sdsvrd.conf")):
		gd.arrCmds.append("cp -a -f /etc/sdsvrd.conf /etc/safedog")
		gd.arrCmds.append("rm -f /etc/sdsvrd.conf")

	gd.sConfFile="/etc/safedog/sdsvrd.conf"
	gd.sConfFileBak="/etc/safedog/backup/sdsvrd.conf.bak"

	return True

def findOpenSsl(bit):
	SearchPaths = []
	if(bit==64):
		SearchPaths.append("/usr/lib64/")
		SearchPaths.append("/lib64/")
	SearchPaths.append("/usr/lib/")
	SearchPaths.append("/lib/")
	FileDir = ""
	FileNamePre = "lib"
	FileNameCore1 = "crypto"
	FileNameCore2 = "ssl"
	FileNameExt = ".so"

	FilePath1 = ""
	FilePath2 = ""

	#ls
	FindAll = False

	sAllLibs = ""
	for FileDir in SearchPaths:
		sOut,sErr = fPopen("ls %s%s%s%s*"%(FileDir,FileNamePre,FileNameCore1,FileNameExt))
		sAllLibs += sOut
	sAllLibs = sAllLibs.strip()
	arrAllLibs = sAllLibs.split("\n")

	for i in arrAllLibs:
		FilePath1 = i
		if ( os.path.isfile(FilePath1) and (not os.path.isdir(FilePath1))):
			sOut,sErr = fPopen("file -L %s | awk '{print $3}'"%i)
			if(int(sOut[0:2]) == gd.longbit):
				#print FilePath1
				sPathTmp = FilePath1
				idx1 = sPathTmp.find(FileNameCore1)
				while(idx1  > 0):
					FilePath2 = sPathTmp[0:idx1] + FileNameCore2 + sPathTmp[idx1+len(FileNameCore1):]
					sPathTmp = FilePath2
					idx1 = sPathTmp.find(FileNameCore1,idx1+2)


				if ( os.path.isfile(FilePath2) and (not os.path.isdir(FilePath2))):
					sOut,sErr = fPopen("file -L %s | awk '{print $3}'"%i)
					if(int(sOut[0:2]) == gd.longbit):
						FindAll = True
						#print FilePath2
						break;
	if( FindAll ):
		return (FilePath1,FilePath2)

	#find
	sAllLibs = ""
	FileNameTmp = FileNamePre + FileNameCore1 + FileNameExt
	for i in SearchPaths:
		sOut,sErr = fPopen("find %s -name %s\\* 2>/dev/null | grep -v /usr/lib/sdcc | grep -v /usr/lib/safedog"%(i,FileNameTmp))
		sAllLibs += sOut

	sAllLibs = sAllLibs.strip()
	arrAllLibs = sAllLibs.split("\n")
	#print "arrAllLibs",arrAllLibs

	for i in arrAllLibs:
		FilePath1 = i
		if ( os.path.isfile(FilePath1) and (not os.path.isdir(FilePath1))):
			sOut,sErr = fPopen("file -L %s | awk '{print $3}'"%i)
			if(int(sOut[0:2]) == gd.longbit):
				#print "FilePath1",FilePath1
				
				sPathTmp = FilePath1
				idx1 = sPathTmp.find(FileNameCore1)
				while(idx1  > 0):
					FilePath2 = sPathTmp[0:idx1] + FileNameCore2 + sPathTmp[idx1+len(FileNameCore1):]
					sPathTmp = FilePath2
					idx1 = sPathTmp.find(FileNameCore1,idx1+2)


				if ( os.path.isfile(FilePath2) and (not os.path.isdir(FilePath2))):
					sOut,sErr = fPopen("file -L %s | awk '{print $3}'"%i)
					if(int(sOut[0:2]) == gd.longbit):
						FindAll = True
						#print "FilePath2",FilePath2
						break;
	if( FindAll ):
		return (FilePath1,FilePath2)
	return ("","")

def stepnow():
	global gd
	gd.iStepNow += 1
	return str(gd.iStepNow)
	
def get_sdcc_version(sdccpath):
	version = ""
	cmd = sdccpath + ' -v'
	(status, output) = commands.getstatusoutput(cmd)
	if(status==0):
		version = output
		cmd = 'ps -Ao pid,args|grep -v grep | grep "' + sdccpath + ' *-v"'
		(status, output) = commands.getstatusoutput(cmd)
		if(status==0) and (len(output)!=0):
			lines = output.split('\n')
			for str in lines:
				temp=str.lstrip()
				pid=int(temp.split(' ')[0])
				os.kill(pid, 9)
	return version

def is_cover_sdcc():
	ver1=get_sdcc_version('sdcc')
	ver2=get_sdcc_version('./dependpkg/bin/sdcc')
	if(len(ver1)==0) or (ver2 > ver1):
		return 1
	else:
		return 0



if __name__ == "__main__":
	main()
	sys.exit(0)

